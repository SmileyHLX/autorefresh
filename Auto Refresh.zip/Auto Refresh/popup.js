let toggleButton = document.getElementById("toggle");
let countdownElem = document.getElementById("countdown");
let intervalInput = document.getElementById("interval");
let activeTabsList = document.getElementById("activeTabsList"); // List to show active tabs

// When the popup is opened, check the state of the current tab and list all active tabs
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    let currentTabId = tabs[0].id;
    let currentTabUrl = tabs[0].url;  // Get the URL of the active tab

    chrome.storage.local.get(['tabTimers', 'intervals'], (data) => {
        let tabTimers = data.tabTimers || {};
        let intervals = data.intervals || {};

        // Update the button text based on the current tab's state
        if (tabTimers[currentTabId]) {
            toggleButton.textContent = "Off";
            countdownElem.textContent = tabTimers[currentTabId].timeLeft;
        } else {
            toggleButton.textContent = "On";
            countdownElem.textContent = "--";
        }

        // Set the interval value for the current tab (if exists)
        if (intervals[currentTabUrl]) {
            intervalInput.value = intervals[currentTabUrl];
        }

        // Display all active tabs using the extension
        displayActiveTabs(tabTimers);
    });
});

// Listen for changes and refresh the active tabs list
chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'updateTabs') {
        chrome.storage.local.get(['tabTimers'], (data) => {
            let tabTimers = data.tabTimers || {};
            displayActiveTabs(tabTimers);
        });
    }
});

toggleButton.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        let currentTabId = tabs[0].id;
        let currentTabUrl = tabs[0].url;  // Get the URL of the active tab

        chrome.storage.local.get(['tabTimers', 'intervals'], (data) => {
            let tabTimers = data.tabTimers || {};
            let intervals = data.intervals || {};

            if (tabTimers[currentTabId]) {
                // Stop refreshing on the current tab
                chrome.runtime.sendMessage({ type: 'stop', tabId: currentTabId });

                // Change toggle button text and clear countdown
                toggleButton.textContent = "On";
                countdownElem.textContent = "--";
            } else {
                // Start refreshing on the current tab
                let interval = parseInt(intervalInput.value);
                if (isNaN(interval) || interval < 1) {
                    alert("Please enter a valid number.");
                    return;
                }

                // Save the input interval value for the current page URL
                intervals[currentTabUrl] = interval;
                chrome.storage.local.set({ intervals });

                // Start the timer for the current tab
                chrome.runtime.sendMessage({ type: 'start', interval, tabId: currentTabId }, (response) => {
                    if (response.status === 'started') {
                        toggleButton.textContent = "Off";
                        startCountdown(currentTabId, interval);
                    }
                });
            }

            // Refresh the active tabs list immediately after the button press
            chrome.storage.local.get(['tabTimers'], (data) => {
                let tabTimers = data.tabTimers || {};
                displayActiveTabs(tabTimers);
            });
        });
    });
});

// Listen for countdown updates from the background script
chrome.runtime.onMessage.addListener((message) => {
    if (message.type === 'updateCountdown') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            let currentTabId = tabs[0].id;
            if (message.tabId === currentTabId) {
                countdownElem.textContent = message.timeLeft;
            }
        });
    }

    // Listen for the "clearCountdown" message and stop showing the timer
    if (message.type === 'clearCountdown') {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            let currentTabId = tabs[0].id;
            if (message.tabId === currentTabId) {
                countdownElem.textContent = "--";
            }
        });
    }
});

function startCountdown(tabId, interval) {
    chrome.storage.local.get(['tabTimers'], (data) => {
        let tabTimers = data.tabTimers || {};
        tabTimers[tabId] = { timeLeft: interval };

        // Update the countdown value in storage for this tab
        chrome.storage.local.set({ tabTimers }, () => {
            countdownElem.textContent = interval;
        });
    });
}

// Function to display all active tabs
function displayActiveTabs(tabTimers) {
    activeTabsList.innerHTML = ''; // Clear previous list

    // Loop through each tab in tabTimers and display its info
    for (let tabId in tabTimers) {
        let tab = tabTimers[tabId];
        let listItem = document.createElement("li");

        // Get tab information asynchronously (tab title only)
        chrome.tabs.get(parseInt(tabId), (tabInfo) => {
            if (tabInfo) {
                listItem.textContent = tabInfo.title;  // Only display tab title
                activeTabsList.appendChild(listItem);
            }
        });
    }
}

// Call displayActiveTabs periodically to keep the list refreshed
setInterval(() => {
    chrome.storage.local.get(['tabTimers'], (data) => {
        let tabTimers = data.tabTimers || {};
        displayActiveTabs(tabTimers);
    });
}, 10000); // Refresh every 10 seconds
