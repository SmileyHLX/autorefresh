let tabTimers = {}; // Store individual timers for each tab
let activeTabId = null; // Track the active tab for displaying the countdown

chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.set({ tabTimers: {} });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'start') {
        startRefreshing(message.interval, message.tabId);
        sendResponse({ status: 'started' });
    } else if (message.type === 'stop') {
        stopRefreshing(message.tabId);
        sendResponse({ status: 'stopped' });
    } else if (message.type === 'getCountdown') {
        sendResponse({ timeLeft: tabTimers[message.tabId]?.timeLeft || 0 });
    }
    return true; // Keeps the sendResponse function valid for async usage
});

function startRefreshing(refreshInterval, tabId) {
    if (tabTimers[tabId]) return; // Prevent multiple timers on the same tab

    // Initialize a separate timer for this tab
    tabTimers[tabId] = { timeLeft: refreshInterval, timer: null, interval: refreshInterval };

    chrome.storage.local.set({ tabTimers });

    // Start the countdown for this specific tab
    startTabCountdown(tabId);
}

function startTabCountdown(tabId) {
    let tabTimer = tabTimers[tabId];

    // Start the timer for this specific tab
    tabTimer.timer = setInterval(() => {
        if (!tabTimers[tabId]) return; // Ensure tab still exists before updating

        tabTimer.timeLeft--; // Decrease the timeLeft for this tab

        // When the countdown hits 0, refresh the page and reset the timer
        if (tabTimer.timeLeft <= 0) {
            chrome.tabs.reload(tabId, () => {
                if (chrome.runtime.lastError) {
                    stopRefreshing(tabId); // Stop timer if the tab no longer exists
                }
            });
            tabTimer.timeLeft = tabTimer.interval; // Reset the timeLeft to the original interval
        }

        // Update the timeLeft for this tab in storage
        chrome.storage.local.set({ tabTimers });

        // Send updated timeLeft to the popup of this tab
        chrome.runtime.sendMessage({ type: 'updateCountdown', timeLeft: tabTimer.timeLeft, tabId })
            .catch(() => {}); // Suppress errors if no listener exists

        // Update the extension icon's badge with the countdown for this tab
        updateIcon(tabId);
    }, 1000); // Update every second
}

function updateIcon(tabId) {
    let tabTimer = tabTimers[tabId];
    if (!tabTimer) return;

    const timeLeft = tabTimer.timeLeft;

    if (timeLeft > 0) {
        const timeString = `${timeLeft}`;
        chrome.action.setBadgeText({ text: timeString, tabId: tabId }).catch(() => {});
        chrome.action.setBadgeBackgroundColor({ color: [255, 255, 0, 255], tabId: tabId }).catch(() => {});
    } else {
        chrome.action.setBadgeText({ text: '', tabId: tabId }).catch(() => {}); // Clear the badge when the timer is off
    }
}

function stopRefreshing(tabId) {
    // Clear the specific tab's timer if it exists
    if (tabTimers[tabId]) {
        clearInterval(tabTimers[tabId].timer); // Stop the tab's timer
        delete tabTimers[tabId]; // Remove the tab from tabTimers
    }

    chrome.storage.local.set({ tabTimers });
    chrome.runtime.sendMessage({ type: 'clearCountdown', tabId }).catch(() => {});

    // Reset the badge icon when no active timer
    chrome.action.setBadgeText({ text: '', tabId: tabId }).catch(() => {});
}

// Track active tab changes
chrome.tabs.onActivated.addListener((activeInfo) => {
    const newActiveTabId = activeInfo.tabId;

    // Clear the badge for the previous active tab
    if (activeTabId !== null && tabTimers[activeTabId]) {
        chrome.action.setBadgeText({ text: '', tabId: activeTabId }).catch(() => {});
    }

    // Set the new active tab as the active tab and update the badge
    activeTabId = newActiveTabId;
    if (tabTimers[activeTabId]) {
        updateIcon(activeTabId); // Show countdown for the active tab
    }
});
